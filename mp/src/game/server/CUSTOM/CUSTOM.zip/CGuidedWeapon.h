#ifndef CGUIDEDWEAPON_H
#define CGUIDEDWEAPON_H
#ifdef _WIN32
#pragma once
#endif
#include <cbase.h>
//#include <hl1mp_basecombatweapon_shared.h>
#include "basecombatweapon.h"
#include <gamerules.h>
#include <Sprite.h>

#include "tier0/memdbgon.h"

#define SPRITE_MATERIAL "sprites/redglow_mp1.vmt"
#define SPRITE_TRANS kRenderWorldGlow, 255, 0, 0, 255, kRenderFxNoDissipation

#define VECTORGOOD Vector(0.001f, 0.001f, 0.001f)
#define VECTORNOAIM Vector(0.1f, 0.1f, 0.1f)

ConVar cstm_dot_size("cstm_dot_size", "0.1f", FCVAR_ARCHIVE);
#define DOTSIZE cstm_dot_size.GetFloat()

class CSprite;

/*
class CGuidedDot : public CSprite
{
	DECLARE_CLASS(CGuidedDot, CSprite);
public:
	static CGuidedDot* CGuidedDot::CreateDot(const Vector& origin, CBaseEntity* pOwner);
};
CGuidedDot* CGuidedDot::CreateDot(const Vector& origin, CBaseEntity* pOwner)
{
#ifndef CLIENT_DLL
	CGuidedDot* pSpot = (CGuidedDot*)CBaseEntity::Create("guided_laser_spot", origin, QAngle(0, 0, 0));

	if (pSpot == NULL)
		return NULL;

	pSpot->SetMoveType(MOVETYPE_NONE);
	pSpot->AddSolidFlags(FSOLID_NOT_SOLID);
	pSpot->AddEffects(EF_NOSHADOW);
	UTIL_SetSize(pSpot, -Vector(6, 6, 6), Vector(6, 6, 6));

	pSpot->SetOwnerEntity(pOwner);

	pSpot->AddEFlags(EFL_FORCE_CHECK_TRANSMIT);

	return pSpot;
#else
	return NULL;
#endif
}*/

class CGuidedWeapon : public CBaseCombatWeapon //CBaseHL1MPCombatWeapon
{
	DECLARE_CLASS(CGuidedWeapon, CBaseCombatWeapon); //CBaseHL1MPCombatWeapon);
	DECLARE_DATADESC();
	DECLARE_SERVERCLASS();

public:
	CGuidedWeapon(void);
	~CGuidedWeapon(void);

//	void DotOn(void);
//	void DotOff(void);
//	void DotRecoil(void);

//	bool bDot;
//	bool bHelperDot;

	CNetworkVar(bool, bDot);
	CNetworkVar(bool, bHelperDot);
	CNetworkVar(bool, bReloadDot);

//private:
	void Spawn(void);
	bool Deploy(void);
	void PrimaryAttack(void);
	void SecondaryAttack(void);
	void Precache(void);
	bool Reload(void);
	void ItemPostFrame(void);
//	void ItemPreFrame(void);
	bool Holster(CBaseCombatWeapon* pSwitchingTo);
	void ToggleDot(void);
	void UpdateDotPos(void);
	void SpawnDot(void);
	void FinishReload(void);
	void WeaponIdle(void);

	bool IsDotOn(void);

	CSprite *pSprite;			//[1];
//	CBasePlayer* pPlayer;

private:
//	trace_t tr;
//	Vector VecStart;
//	Vector VecDir;
//	Vector VecEnd;
};
IMPLEMENT_SERVERCLASS_ST(CGuidedWeapon, DT_GuidedWeapon)
END_SEND_TABLE();

LINK_ENTITY_TO_CLASS(weapon_guided, CGuidedWeapon);
PRECACHE_WEAPON_REGISTER(weapon_guided);
BEGIN_DATADESC(CGuidedWeapon)
DEFINE_FIELD(bDot, FIELD_BOOLEAN),
//DEFINE_FIELD(vecOrigin, FIELD_VECTOR),
DEFINE_FIELD(bHelperDot, FIELD_BOOLEAN),
DEFINE_FIELD(bReloadDot, FIELD_BOOLEAN),
DEFINE_FIELD(pSprite, FIELD_CLASSPTR),
//DEFINE_ARRAY(pSprite, FIELD_CLASSPTR, 1),
END_DATADESC();
#endif //CGUIDEDWEAPON_H